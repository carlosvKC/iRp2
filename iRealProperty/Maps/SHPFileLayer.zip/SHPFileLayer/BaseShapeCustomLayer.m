#import "BaseShapeCustomLayer.h"



@implementation BaseShapeCustomLayer

@synthesize titleColumnName;
@synthesize descriptionColumName;
@synthesize renderSymbol;
@synthesize attributeNames;

@end
